<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('customer/showitem/{id}','CustomerController@showitem')->name('customer.showitem');
Route::get('customer/createitem/{id}','CustomerController@createitem')->name('customer.createitem');
Route::post('customer/storeitem','CustomerController@storeitem')->name('customer.storeitem');
Route::get('customer/destroyitem/{id}','CustomerController@destroyitem')->name('customer.destroyitem');

Route::get('customer/status/{id}','CustomerController@Status')->name('customer.status');
Route::post('customer/insertstatus','CustomerController@InsertStatus')->name('customer.insertstatus');
Route::get('customer/viewstatus/{id}','CustomerController@ViewStatus')->name('customer.viewstatus');
Route::get('customer/pickstaff/{id}','CustomerController@Pickstaff')->name('customer.pickstaff');
Route::post('customer/storepickstaff','CustomerController@Storepickstaff')->name('customer.storepickstaff');

Route::get('staffs/viewcus/{id}','StaffController@Viewcus')->name('staffs.viewcus');

Route::get('customer/calmember/{id}','CustomerController@Calmember')->name('customer.calmember');
Route::get('warehouse/deleteall','WarehouseController@DeleteAll')->name('warehouse.deleteall');

Route::get('/', function () {
    return view('welcome');
});

Route::resource('warehouse','WarehouseController');

Route::resource('staffs','StaffController');

Route::resource('customer','CustomerController');



Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
