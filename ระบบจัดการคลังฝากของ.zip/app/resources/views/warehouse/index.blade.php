@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-10">
        <div >
            <div class="panel panel-default">
                <div class="panel-heading">
                <div>
                <a class="btn btn-danger" href="{{ route('warehouse.deleteall') }}"><i class='fas fa-exclamation-triangle' style='font-size:24px'></i>  เคลียร์คลังสินค้าทั้งหมด</a>
                <center><h2>ประวัติคลังของทั้งหมด</h2></center>
                <br>
                </div>
                    <table class="table table-striped" >
                    <tr>
                        <td>รหัสของฝาก</td>
                        <td>ชื่อของฝาก</td>
                        <td>รายละเอียด</td>
                        <td>วันที่มาฝากของ</td>
                        <td>ชื่อผู้ฝาก</td>
                        <td>การดำเนินการ</td>
                    </tr>
                    @foreach($item as $it)
                    <tr>
                        <td>{{ $it->Item_ID }}</td>
                        <td>{{ $it->Item_Name }}</td>
                        <td>{{ $it->Detail }}</td>
                        <td>{{ $it->Deposit_Date }}</td>
                        <td>{{ $it->Item_Recipients }}</td>
                        <td>
                        <form action="{{ route('warehouse.destroy',$it->Item_ID) }}" method="POST">
                        <a class="btn btn-primary" href="{{ route('warehouse.show',$it->Item_ID) }}"><i class='far fa-calendar-alt' style='font-size:18px'></i>  สถานะการรับของ</a>
                            @csrf
                            @method("DELETE")
                            <button type="submit" class="btn btn-danger"><i class='fas fa-trash' style='font-size:18px'></i></button>
                        </form>
                        </td>
                    </tr>
                    @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection