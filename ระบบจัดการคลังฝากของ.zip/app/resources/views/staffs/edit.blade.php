@extends('layouts.app')

@section('content')
@foreach($staffs as $st)
@endforeach
<div class="container">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <a class="btn btn-primary" href="http://localhost:8080/staffs">ย้อนกลับ</a>
                <center><h2>แก้ไขข้อมูลพนักงาน
                    <br>
                    <br>
                </div>
                <form action="{{ route('staffs.update',$st->Staff_No) }}" method="POST">
                @csrf 
                @method("PUT")   
                <table class="table table-striped" border='2'>
                       <tr>
                            <td>ชื่อ:</td>
                            <td><input type=text name=Staff_Name value="{{ $st->Staff_Name }}"></td>
                       </tr>
                       <tr>
                            <td>นามสกุล:</td>
                            <td><input type=text name=Staff_Surname value="{{ $st->Staff_Surname }}"></td>
                       </tr>
                       <tr>
                            <td>เบอร์โทรศัพท์:</td>
                            <td><input type=text name=Staff_Phone value="{{ $st->Staff_Phone }}"></td>
                       </tr>
                       <tr>
                            <td>อีเมล:</td>
                            <td><input type=text name=Staff_Email value="{{ $st->Staff_Email }}"></td>
                       </tr>
                        
                       <tr>
                        <td></td>
                        <td conspan=2>
                        <button type="reset"  class="btn btn-danger">ยกเลิก</button>
                        <button type="submit"  class="btn btn-primary">แก้ไขข้อมูล</button>
                        </td>
                        </tr>


                    </table>
                </form>
            </div>
        </div>
</div>
@endsection
