@extends('layouts.app')

@section('content')
<div class="container">
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-10">
            <div class="panel panel-default">
                <div class="panel-heading">
                <div>
                <a class="btn btn-primary" href="{{ route('staffs.create') }}"><i class='fas fa-user-plus' style='font-size:20px'></i>  เพิ่มพนักงาน</a>
                <center><h2>ข้อมูลพนักงานทั้งหมด</h2> </center>
                <br>
                <br>
                </div>
                    <table class="table table-striped" width= “300” height= “200”>
                    
                    <tr>
                        <td>รหัสพนักงาน</td>
                        <td>ชื่อ</td>
                        <td>นามสกุล</td>
                        <td>เบอร์โทรศัพท์</td>
                        <td>อีเมล</td>
                        <td>การดำเนินงาน</td>
                    </tr>
                    @foreach($staffs as $st)
                    <tr>
                        <td>{{ $st->Staff_No }}</td>
                        <td>{{ $st->Staff_Name }}</td>
                        <td>{{ $st->Staff_Surname }}</td>
                        <td>{{ $st->Staff_Phone }}</td>
                        <td>{{ $st->Staff_Email }}</td>
                        <td>
                        <form action="{{ route('staffs.destroy',$st->Staff_No) }}" method="POST">
                            <a class="btn btn-primary" href="{{ route('staffs.viewcus',$st->Staff_No) }}"><i class='fas fa-address-book' style='font-size:18px'></i> การดูแลลูกค้า</a>
                            <a class="btn btn-warning" href="{{ route('staffs.edit',$st->Staff_No) }}">แก้ไขข้อมูล</a>
                            @csrf
                            @method("DELETE")
                            <button type="submit" class="btn btn-danger"><i class='fas fa-trash' style='font-size:18px'></i></button>
                        </form>
                        </td>
                    </tr>
                    @endforeach
                    </table>
                </div>
            </div>
            </main>
</div>
@endsection
