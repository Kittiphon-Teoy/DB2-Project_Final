@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading" >
                <a class="btn btn-primary" href="http://localhost:8080/staffs">ย้อนกลับ</a>
                <center><h2>ลูกค้าที่ดูแล</center>
                <br>
                </div>
                
                @csrf 
                @method("POST")   
                <table class="table table-striped" border='2'>
                @foreach ($cushasstaff as $chs)
                        <tr>
                            <td><center>รหัสลูกค้า :</center></td>
                            <td><center>{{ $chs->Customer_ID }}</center></td>
                       </tr>
                @endforeach
                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
