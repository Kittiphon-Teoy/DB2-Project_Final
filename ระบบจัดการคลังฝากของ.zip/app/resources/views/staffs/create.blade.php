@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-10">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <a class="btn btn-primary" href="http://localhost:8080/staffs">ย้อนกลับ</a>
                <center><h2>เพิ่มพนักงาน</center>
                <br>
                <br>
                </div>
                <form action="{{ route('staffs.store') }}" method="POST">
                @csrf 
                @method("POST")   
                <table class="table table-striped" border='2'>
                       <tr>
                            <td>ชื่อ:</td>
                            <td><input type=text name=Staff_Name></td>
                       </tr>
                       <tr>
                            <td>นามสกุล:</td>
                            <td><input type=text name=Staff_Surname></td>
                       </tr>
                       <tr>
                            <td>เบอร์โทรศัพท์:</td>
                            <td><input type=text name=Staff_Phone></td>
                       </tr>
                       <tr>
                            <td>อีเมล:</td>
                            <td><input type=text name=Staff_Email></td>
                       </tr>
                        
                       <tr>
                        <td></td>
                        <td>
                        <button type="reset"  class="btn btn-danger">ยกเลิก</button>
                        <button type="submit"  class="btn btn-primary">บันทึกข้อมูล</button>
                        </td>
                        </tr>


                    </table>
                </form>
            </div>
        </div>
        </main>
    </div>
</div>
@endsection
