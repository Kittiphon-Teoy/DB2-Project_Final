@extends('layouts.app')

@section('content')
@foreach($customer as $cus)
@endforeach
@foreach($status as $sta)
@endforeach
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <center><h2>แก้ไขข้อมูลลูกค้า</h2></center>
                <br>
                </div>
                <form action="{{ route('customer.update',$cus->Customer_ID) }}" method="POST">
                @csrf 
                @method("PUT")   
                <table class="table table-striped" border='2'>
                       <tr>
                            <td>ชื่อลูกค้า:</td>
                            <td><input type=text name=Name value="{{ $cus->Name }}"></td>
                       </tr>
                       <tr>
                            <td>นามสกุล:</td>
                            <td><input type=text name=Surname value="{{ $cus->Surname }}"></td>
                       </tr>
                       <tr>
                            <td>เบอร์โทรศัพท์:</td>
                            <td><input type=text name=Phone value="{{ $cus->Phone }}"></td>
                       </tr>
                       <tr>
                            <td>อีเมล:</td>
                            <td><input type=text name=Email value="{{ $cus->Email }}"></td>
                       </tr>
                       <tr>
                            <td>รหัสสถานะ:</td>
                            <td>
                                <select name="Status_No">
                                    <option value="{{ $cus->Status_No }}">{{ $cus->Status_No }}</option>
                                    <option value="1">1:Normal</option>
                                    <option value="2">2:Bronze</option>
                                    <option value="3">3:Silver</option>
                                    <option value="4">4:Gold</option>
                                </select>
                            </td>
                       </tr>
                        
                       <tr>
                        <td></td>
                        <td conspan=2>
                        <button type="reset"  class="btn btn-danger">ยกเลิก</button>
                        <button type="submit"  class="btn btn-primary">แก้ไขข้อมูล</button>
                        </td>
                        </tr>


                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
