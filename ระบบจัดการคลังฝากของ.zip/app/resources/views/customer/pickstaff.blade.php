@extends('layouts.app')

@foreach($customer as $cus)
@endforeach
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                   <center><h2>เลือกผู้ดูแล
                       <br>
                       <br>
                </div>
                <form action="{{ route('customer.storepickstaff', $cus->Customer_ID) }}" method="POST">
                @csrf  
                @method("POST")   
                <table class="table table-striped">
                       <input type=hidden name=Customer_ID value="{{ $cus->Customer_ID }}">
                       <tr>
                            <td>พนักงาน:</td>
                            <td>
                                <select name="Staff_No">
                                @foreach ($staff as $st) 
                                    <option value="{{ $st->Staff_No }}">{{ $st->Staff_No }} : {{ $st->Staff_Name }} 
                                @endforeach
                                </select>
                            </td>
                       </tr>
                       <tr>
                        <td conspan=2>
                        <button type="submit"  class="btn btn-success">เลือก</button>
                        </td>
                        </tr>


                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
