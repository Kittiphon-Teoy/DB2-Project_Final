@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <center><h2>เพิ่มลูกค้าใหม่
                    <br>
                </div>
                <form action="{{ route('customer.store') }}" method="POST">
                @csrf 
                @method("POST")   
                <table class="table table-striped" border='2'>
                       <tr>
                            <td>ชื่อลูกค้า:</td>
                            <td><input type=text name=Name></td>
                       </tr>
                       <tr>
                            <td>นามสกุล:</td>
                            <td><input type=text name=Surname></td>
                       </tr>
                       <tr>
                            <td>เบอร์โทรศัพท์:</td>
                            <td><input type=text name=Phone></td>
                       </tr>
                       <tr>
                            <td>อีเมล:</td>
                            <td><input type=text name=Email></td>
                       </tr>
                       
                       <tr>
                            <td>รหัสสถานะ:</td>
                            <td>
                                <select name="Status_No">
                                @foreach($status as $sta)
                                    <option value="{{ $sta->Status_No }}">{{ $sta->Status_No }} : {{ $sta->Status_Name }} 
                                @endforeach
                                </select>
                            </td>
                       </tr>
                       <tr>
                        <td></td>
                        <td conspan=2>
                        <button type="reset"  class="btn btn-danger">ยกเลิก</button>
                        <button type="submit"  class="btn btn-primary">บันทึกข้อมูล</button>
                        </td>
                        </tr>


                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
