@extends('layouts.app')


@foreach ($item as $it) 
@endforeach
@foreach ($Status_Item as $sti) 
@endforeach
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <center><h2>สถานะการรับของ</center>
                <br>
                </div>
                @csrf 
                @method("POST")   
                <table class="table table-striped" border='2'>
                        <tr>
                            <td>รหัสของฝาก:</td>
                            <td><input type=text value="{{ $it->Item_ID }}" readonly name=Item_ID ></td>
                       </tr>
                       <tr>
                            <td>ชื่อของฝาก:</td>
                            <td><input type=text value="{{ $it->Item_Name }}" readonly></td>
                       </tr>
                       <tr>
                            <td>วันเวลาที่บันทึก:</td>
                            <td><input type=text value="{{ $sti->Pickup_Date }}" readonly></td>
                       </tr>
                       <tr>
                            <td>สถานะ:</td>
                            <td>
                            <input type=button class="btn btn-warning" value="{{ $sti->Status_Item }}" readonly name="Status_Item"  >
                            </td>
                       </tr>


                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
