@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-10">
            <div class="panel panel-default">
                <div class="panel-heading">
                <div>
                <a class="btn btn-primary" href="{{ route('customer.create') }}"><i class='fas fa-user-plus' style='font-size:20px'></i>  เพิ่มข้อมูลลูกค้า</a>
                <center> <h2>ข้อมูลลูกค้าทั้งหมด</h2> </center>  
                <br>
                <br>
                </div>
                    <table class="table table-striped" width= “300” height= “200”>
                    
                    <tr>
                        <td>รหัสลูกค้า</td>
                        <td>ชื่อ</td>
                        <td>นามสกุล</td>
                        <td>เบอร์โทรศัพท์</td>
                        <td>อีเมล</td>
                        <td>รหัสสถานะ</td>
                        <td>การดำเนินงาน</td>
                    </tr>
                    
                    @foreach($customer as $cus)
                    <tr>
                        <td>{{ $cus->Customer_ID }}</td>
                        <td>{{ $cus->Name }}</td>
                        <td>{{ $cus->Surname }}</td>
                        <td>{{ $cus->Phone }}</td>
                        <td>{{ $cus->Email }}</td>
                        <td>{{ $cus->Status_No }}</td>
                        <td>
                        <form action="{{ route('customer.destroy',$cus->Customer_ID) }}" method="POST">
                            <a class="btn btn-warning" href="{{ route('customer.pickstaff',$cus->Customer_ID) }}"><i class='fas fa-users-cog' style='font-size:18px'></i> เลือกผู้ดูแล*</a>
                            <a class="btn btn-success" href="{{ route('customer.showitem',$cus->Customer_ID ) }}"><i class='fas fa-archive' style='font-size:18px'></i>  ของที่ฝาก</a>
                            <a class="btn btn-primary" href="{{ route('customer.edit',$cus->Customer_ID) }}"><i class='fas fa-user-edit' style='font-size:18px'></i></a>
                            @csrf
                            @method("DELETE")
                            <button type="submit" class="btn btn-danger"><i class='fas fa-trash' style='font-size:18px'></i></button>
                        </form>
                        </td>
                    </tr>
                    @endforeach
                    </table>
                </div>
            </div>
            </main>
    </div>
</div>
@endsection
