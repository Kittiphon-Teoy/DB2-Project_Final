@extends('layouts.app')

@foreach($customer as $cus)
@foreach($cushasstaff as $chs)
@endforeach
@section('content')
<div class="container">
    <div class="row">
        <div >
            <div class="panel panel-default">
                <div class="panel-heading">
                <center><h2>ของที่ฝาก</h2></center>
                <div>
                <a class="btn btn-primary" href="{{ route('customer.createitem',$cus->Customer_ID) }}">เพิ่มของที่ฝาก</a>
                <br>
                <br>
                <h5>รหัสผู้ที่ดูแล : {{ $chs->Staff_No }}</h5><br>
                </div>
                    <table class="table table-striped">
                    <tr>
                        <td>รหัสของฝาก</td>
                        <td>ชื่อของฝาก</td>
                        <td>รายละเอียด</td>
                        <td>วันที่มาฝากของ</td>
                        <td>ชื่อผู้ฝาก</td>
                        <td>ค่าฝาก</td>
                        <td>ส่วนลดสมาชิก</td>
                        <td colspan=2>การดำเนินงาน</td>
                    </tr>
                    @foreach($item as $it)
                    <tr>
                        <td>{{ $it->Item_ID }}</td>
                        <td>{{ $it->Item_Name }}</td>
                        <td>{{ $it->Detail }}</td>
                        <td>{{ $it->Deposit_Date }}</td>
                        <td>{{ $it->Item_Recipients }}</td>
                        <td>{{ $it->Price }}</td>
                        <td><center><a class="btn btn-info" href="{{ route('customer.calmember', $it->Item_ID) }}"><i class='fas fa-money-check-alt' style='font-size:26px'></i></i></a></center></td>
                        <td>
                        <form action="{{ route('customer.destroyitem',$it->Item_ID) }}" method="GET">
                        <a class="btn btn-warning" href="{{ route('customer.status', $it->Item_ID) }}">บันทึกวันรับของ*</a>
                            <a class="btn btn-success" href="{{ route('customer.viewstatus',$it->Item_ID) }}">ดูสถานะวันรับของ</a>
                             @csrf
                             @method("DELETE")
                            <button type="submit" class="btn btn-danger">ลบ</button>
                        </form>
                        </td>
                    </tr>
                    @endforeach
                    @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection