

<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                   <center><h2>เลือกผู้ดูแล
                       <br>
                       <br>
                </div>
                <form action="<?php echo e(route('customer.storepickstaff', $cus->Customer_ID)); ?>" method="POST">
                <?php echo csrf_field(); ?>  
                <?php echo method_field("POST"); ?>   
                <table class="table table-striped">
                       <input type=hidden name=Customer_ID value="<?php echo e($cus->Customer_ID); ?>">
                       <tr>
                            <td>พนักงาน:</td>
                            <td>
                                <select name="Staff_No">
                                <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($st->Staff_No); ?>"><?php echo e($st->Staff_No); ?> : <?php echo e($st->Staff_Name); ?> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                       </tr>
                       <tr>
                        <td conspan=2>
                        <button type="submit"  class="btn btn-success">เลือก</button>
                        </td>
                        </tr>


                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/customer/pickstaff.blade.php ENDPATH**/ ?>