


<?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $stitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <center><h2>สถานะการรับของ</h2></center>
                <br>
                </div>
                <?php echo csrf_field(); ?> 
                <?php echo method_field("POST"); ?>   
                <table class="table table-striped" border='2'>
                        <tr>
                            <td>รหัสของฝาก:</td>
                            <td><input type=text value="<?php echo e($it->Item_ID); ?>" readonly name=Item_ID ></td>
                       </tr>
                       <tr>
                            <td>ชื่อของฝาก:</td>
                            <td><input type=text value="<?php echo e($it->Item_Name); ?>" readonly></td>
                       </tr>
                       <tr>
                            <td>วันเวลาที่บันทึก:</td>
                            <td><input type=text value="<?php echo e($sti->Pickup_Date); ?>" readonly></td>
                       </tr>
                       <tr>
                            <td>สถานะ:</td>
                            <td>
                            <input type=button class="btn btn-primary" value="<?php echo e($sti->Status_Item); ?>" readonly name="Status_Item"  >
                            </td>
                       </tr>


                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/warehouse/showdate.blade.php ENDPATH**/ ?>