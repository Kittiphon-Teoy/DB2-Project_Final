

<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $cushasstaff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div >
            <div class="panel panel-default">
                <div class="panel-heading">
                <center><h2>ของที่ฝาก</h2></center>
                <div>
                <a class="btn btn-primary" href="<?php echo e(route('customer.createitem',$cus->Customer_ID)); ?>">เพิ่มของที่ฝาก</a>
                <br>
                <br>
                <h5>รหัสผู้ที่ดูแล : <?php echo e($chs->Staff_No); ?></h5><br>
                </div>
                    <table class="table table-striped">
                    <tr>
                        <td>รหัสของฝาก</td>
                        <td>ชื่อของฝาก</td>
                        <td>รายละเอียด</td>
                        <td>วันที่มาฝากของ</td>
                        <td>ชื่อผู้ฝาก</td>
                        <td>ค่าฝาก</td>
                        <td>ส่วนลดสมาชิก</td>
                        <td colspan=2>การดำเนินงาน</td>
                    </tr>
                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($it->Item_ID); ?></td>
                        <td><?php echo e($it->Item_Name); ?></td>
                        <td><?php echo e($it->Detail); ?></td>
                        <td><?php echo e($it->Deposit_Date); ?></td>
                        <td><?php echo e($it->Item_Recipients); ?></td>
                        <td><?php echo e($it->Price); ?></td>
                        <td><center><a class="btn btn-info" href="<?php echo e(route('customer.calmember', $it->Item_ID)); ?>"><i class='fas fa-money-check-alt' style='font-size:26px'></i></i></a></center></td>
                        <td>
                        <form action="<?php echo e(route('customer.destroyitem',$it->Item_ID)); ?>" method="GET">
                        <a class="btn btn-warning" href="<?php echo e(route('customer.status', $it->Item_ID)); ?>">บันทึกวันรับของ*</a>
                            <a class="btn btn-success" href="<?php echo e(route('customer.viewstatus',$it->Item_ID)); ?>">ดูสถานะวันรับของ</a>
                             <?php echo csrf_field(); ?>
                             <?php echo method_field("DELETE"); ?>
                            <button type="submit" class="btn btn-danger">ลบ</button>
                        </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/customer/showitem.blade.php ENDPATH**/ ?>