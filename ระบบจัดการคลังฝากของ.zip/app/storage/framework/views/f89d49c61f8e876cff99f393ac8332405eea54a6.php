

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                   เปิดชนิดบัญชีใหม่
                </div>
                <form action="<?php echo e(route('acctype.store')); ?>" method="POST">
                <?php echo csrf_field(); ?> 
                <?php echo method_field("POST"); ?>   
                <table border=1>
                      
                       <tr>
                            <td>ชนิดบัญชี:<td>
                            <td><input type=text name=Type_No></td>
                       </tr>
                       <tr>
                            <td>ชื่อชนิด:<td>
                            <td><input type=text name=Type_Name></td>
                       </tr>
                       <tr>
                            <td>วันที่เริ่ม:<td>
                            <td><input type=text name=DateBegin></td>
                       </tr>
                       <tr>
                            <td>วันที่สิ้นสุด:<td>
                            <td><input type=text name=DateEnd></td>
                       </tr>
                       <tr>
                            <td>เรท:<td>
                            <td><input type=text name=Rate></td>
                       </tr>
                        
                       <tr>
                        <td conspan=2>
                        <button type="reset"  class="btn btn-primary">ยกเลิก</button>
                        <button type="submit"  class="btn btn-primary">บันทึกข้อมูล</button>
                        </td>
                        </tr>


                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/acctype/create.blade.php ENDPATH**/ ?>