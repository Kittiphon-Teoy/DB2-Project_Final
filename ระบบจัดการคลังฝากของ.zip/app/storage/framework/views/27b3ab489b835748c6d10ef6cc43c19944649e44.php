<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <div>
                <a class="btn btn-primary" href="<?php echo e(route('account.create')); ?>">เปิดบัญชี</a>
                    <a class="btn btn-primary" href="">โอนเงิน</a>
                        <a class="btn btn-primary" href="">คำนวณภาษี</a>
                </div>
                    <table border=1>
                    <tr>
                        <td>เลขบัญชี<td>
                        <td>ชนิดบัญชี<td>
                        <td>ชื่อ<td>
                        <td>นามสกุล<td>
                        <td>ที่อยู่<td>
                        <td>ตำบล<td>
                        <td>อำเภอ<td>
                        <td>จังหวัด<td>
                        <td>รหัสไปรษณีย์<td>
                        <td>วันที่เปิดบัญชี<td>
                        <td>จำนวณเงิน<td>
                        <td colspan=2>การดำเนินงาน</td>
                    </tr>
                    <?php $__currentLoopData = $account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($acc->ACC_No); ?><td>
                        <td><?php echo e($acc->Type_No); ?><td>
                        <td><?php echo e($acc->ACC_Name); ?><td>
                        <td><?php echo e($acc->ACC_Surname); ?><td>
                        <td><?php echo e($acc->Address); ?><td>
                        <td><?php echo e($acc->SubDistrict); ?><td>
                        <td><?php echo e($acc->District); ?><td>
                        <td><?php echo e($acc->Province); ?><td>
                        <td><?php echo e($acc->ZipCode); ?><td>
                        <td><?php echo e($acc->DateOp); ?><td>
                        <td><?php echo e($acc->Balance); ?><td>
                        <td>
                            Edite
                            Delete
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Account.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/Account/index.blade.php ENDPATH**/ ?>