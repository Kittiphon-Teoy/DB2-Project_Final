

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <!-- <div class="col-md-8 col-md-offset-2"> -->
            <div class="panel panel-default">
                <div class="panel-heading">
                <div>
                <a class="btn btn-primary" href="<?php echo e(route('staff.create')); ?>">เพิ่มStaff</a>
                                  
                </div>
                    <table border=1>
                    <tr>
                        <td>Staff_No<td>
                        <td>Staff_Name<td>
                        <td>Staff_Surname<td>
                        <td>Staff_Address<td>
                        <td>Staff_Email<td>
                        <td>Staff_Phone<td>
                        <td colspan=2>การดำเนินงาน</td>
                    </tr>
                    <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($stf->Staff_No); ?><td>
                        <td><?php echo e($stf->Staff_Name); ?><td>
                        <td><?php echo e($stf->Staff_Surname); ?><td>
                        <td><?php echo e($stf->Staff_Address); ?><td>
                        <td><?php echo e($stf->Staff_Email); ?><td>
                        <td><?php echo e($stf->Staff_Phone); ?><td>
                        <td>
                        <form action="<?php echo e(route('staff.destroy',$stf->Staff_No)); ?>" method="POST">
                            <a class="btn btn-primary" href="<?php echo e(route('staff.edit',$stf->Staff_No)); ?>">แก้ไข</a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <button type="submit" class="btn btn-danger">ลบ</button>
                        </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        <!-- </div> -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/staff/index.blade.php ENDPATH**/ ?>