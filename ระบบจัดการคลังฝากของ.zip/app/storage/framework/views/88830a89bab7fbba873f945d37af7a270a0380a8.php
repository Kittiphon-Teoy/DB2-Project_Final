<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-10">
            <div class="panel panel-default">
                <div class="panel-heading">
                <div>
                <a class="btn btn-primary" href="<?php echo e(route('customer.create')); ?>"><i class='fas fa-user-plus' style='font-size:20px'></i>  เพิ่มข้อมูลลูกค้า</a>
                <center> <h2>ข้อมูลลูกค้าทั้งหมด</h2> </center>  
                <br>
                <br>
                </div>
                    <table class="table table-striped" width= “300” height= “200”>
                    
                    <tr>
                        <td>รหัสลูกค้า</td>
                        <td>ชื่อ</td>
                        <td>นามสกุล</td>
                        <td>เบอร์โทรศัพท์</td>
                        <td>อีเมล</td>
                        <td>รหัสสถานะ</td>
                        <td>การดำเนินงาน</td>
                    </tr>
                    
                    <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($cus->Customer_ID); ?></td>
                        <td><?php echo e($cus->Name); ?></td>
                        <td><?php echo e($cus->Surname); ?></td>
                        <td><?php echo e($cus->Phone); ?></td>
                        <td><?php echo e($cus->Email); ?></td>
                        <td><?php echo e($cus->Status_No); ?></td>
                        <td>
                        <form action="<?php echo e(route('customer.destroy',$cus->Customer_ID)); ?>" method="POST">
                            <a class="btn btn-warning" href="<?php echo e(route('customer.pickstaff',$cus->Customer_ID)); ?>"><i class='fas fa-users-cog' style='font-size:18px'></i> เลือกผู้ดูแล*</a>
                            <a class="btn btn-success" href="<?php echo e(route('customer.showitem',$cus->Customer_ID )); ?>"><i class='fas fa-archive' style='font-size:18px'></i>  ของที่ฝาก</a>
                            <a class="btn btn-primary" href="<?php echo e(route('customer.edit',$cus->Customer_ID)); ?>"><i class='fas fa-user-edit' style='font-size:18px'></i></a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <button type="submit" class="btn btn-danger"><i class='fas fa-trash' style='font-size:18px'></i></button>
                        </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
            </main>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/customer/index.blade.php ENDPATH**/ ?>