

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading" >
                <a class="btn btn-primary" href="http://localhost:8080/staffs">ย้อนกลับ</a>
                <center><h2>ลูกค้าที่ดูแล</center>
                <br>
                </div>
                
                <?php echo csrf_field(); ?> 
                <?php echo method_field("POST"); ?>   
                <table class="table table-striped" border='2'>
                <?php $__currentLoopData = $cushasstaff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><center>รหัสลูกค้า :</center></td>
                            <td><center><?php echo e($chs->Customer_ID); ?></center></td>
                       </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/staffs/viewcus.blade.php ENDPATH**/ ?>