

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-10">
        <div >
            <div class="panel panel-default">
                <div class="panel-heading">
                <div>
                <a class="btn btn-danger" href="<?php echo e(route('warehouse.deleteall')); ?>"><i class='fas fa-exclamation-triangle' style='font-size:24px'></i>  เคลียร์คลังสินค้าทั้งหมด</a>
                <center><h2>ประวัติคลังของทั้งหมด</h2></center>
                <br>
                </div>
                    <table class="table table-striped" >
                    <tr>
                        <td>รหัสของฝาก</td>
                        <td>ชื่อของฝาก</td>
                        <td>รายละเอียด</td>
                        <td>วันที่มาฝากของ</td>
                        <td>ชื่อผู้ฝาก</td>
                        <td>การดำเนินการ</td>
                    </tr>
                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($it->Item_ID); ?></td>
                        <td><?php echo e($it->Item_Name); ?></td>
                        <td><?php echo e($it->Detail); ?></td>
                        <td><?php echo e($it->Deposit_Date); ?></td>
                        <td><?php echo e($it->Item_Recipients); ?></td>
                        <td>
                        <form action="<?php echo e(route('warehouse.destroy',$it->Item_ID)); ?>" method="POST">
                        <a class="btn btn-primary" href="<?php echo e(route('warehouse.show',$it->Item_ID)); ?>"><i class='far fa-calendar-alt' style='font-size:18px'></i>  สถานะการรับของ</a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <button type="submit" class="btn btn-danger"><i class='fas fa-trash' style='font-size:18px'></i></button>
                        </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/warehouse/index.blade.php ENDPATH**/ ?>