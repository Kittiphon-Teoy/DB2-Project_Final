

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                   แก้ไขข้อมูลStaff
                </div>
                <form action="<?php echo e(route('staff.update',$stf->Staff_No)); ?>" method="POST">
                <?php echo csrf_field(); ?> 
                <?php echo method_field("PUT"); ?>   
                <table border=1>
                        <tr>
                            <td>Staff_No:<td>
                            <td><input type=text name=Staff_No value="<?php echo e($stf->Staff_No); ?>"></td>
                       </tr>
                       <tr>
                            <td>Staff_Name:<td>
                            <td><input type=text name=Staff_Name value="<?php echo e($stf->Staff_Name); ?>"></td>
                       </tr>
                       <tr>
                            <td>Staff_Surname:<td>
                            <td><input type=text name=Staff_Surname value="<?php echo e($stf->Staff_Surname); ?>"></td>
                       </tr>
                       <tr>
                            <td>Staff_Address:<td>
                            <td><input type=text name=Staff_Address value="<?php echo e($stf->Staff_Address); ?>"></td>
                       </tr>
                       <tr>
                            <td>Staff_Email:<td>
                            <td><input type=text name=Staff_Email value="<?php echo e($stf->Staff_Email); ?>"></td>
                       </tr>
                       <tr>
                            <td>Staff_Phone:<td>
                            <td><input type=text name=Staff_Phone value="<?php echo e($stf->Staff_Phone); ?>"></td>
                       </tr>
                        
                       <tr>
                        <td conspan=2>
                        <button type="reset"  class="btn btn-primary">ยกเลิก</button>
                        <button type="submit"  class="btn btn-primary">บันทึกข้อมูล</button>
                        </td>
                        </tr>


                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/staff/edit.blade.php ENDPATH**/ ?>