<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <table border=1>
                    <tr>
                        <td>Tran_No<td>
                        <td>ACC_No <td>
                        <td>DateOp<td>
                        <td>Amount<td>
                        
                    </tr>
                    <?php $__currentLoopData = $deposit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($depo->Tran_No); ?><td>
                        <td><?php echo e($depo->ACC_No); ?><td>
                        <td><?php echo e($depo->DateOp); ?><td>
                        <td><?php echo e($depo->Amount); ?><td>
                        
                      
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Deposit.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/Deposit/index.blade.php ENDPATH**/ ?>