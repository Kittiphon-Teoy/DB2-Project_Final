<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="container">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <a class="btn btn-primary" href="http://localhost:8080/staffs">ย้อนกลับ</a>
                <center><h2>แก้ไขข้อมูลพนักงาน
                    <br>
                    <br>
                </div>
                <form action="<?php echo e(route('staffs.update',$st->Staff_No)); ?>" method="POST">
                <?php echo csrf_field(); ?> 
                <?php echo method_field("PUT"); ?>   
                <table class="table table-striped" border='2'>
                       <tr>
                            <td>ชื่อ:</td>
                            <td><input type=text name=Staff_Name value="<?php echo e($st->Staff_Name); ?>"></td>
                       </tr>
                       <tr>
                            <td>นามสกุล:</td>
                            <td><input type=text name=Staff_Surname value="<?php echo e($st->Staff_Surname); ?>"></td>
                       </tr>
                       <tr>
                            <td>เบอร์โทรศัพท์:</td>
                            <td><input type=text name=Staff_Phone value="<?php echo e($st->Staff_Phone); ?>"></td>
                       </tr>
                       <tr>
                            <td>อีเมล:</td>
                            <td><input type=text name=Staff_Email value="<?php echo e($st->Staff_Email); ?>"></td>
                       </tr>
                        
                       <tr>
                        <td></td>
                        <td conspan=2>
                        <button type="reset"  class="btn btn-danger">ยกเลิก</button>
                        <button type="submit"  class="btn btn-primary">แก้ไขข้อมูล</button>
                        </td>
                        </tr>


                    </table>
                </form>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/staffs/edit.blade.php ENDPATH**/ ?>