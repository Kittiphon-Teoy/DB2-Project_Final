

<?php $__env->startSection('content'); ?>
<div class="container">
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-10">
            <div class="panel panel-default">
                <div class="panel-heading">
                <div>
                <a class="btn btn-primary" href="<?php echo e(route('staffs.create')); ?>"><i class='fas fa-user-plus' style='font-size:20px'></i>  เพิ่มพนักงาน</a>
                <center><h2>ข้อมูลพนักงานทั้งหมด</h2> </center>
                <br>
                <br>
                </div>
                    <table class="table table-striped" width= “300” height= “200”>
                    
                    <tr>
                        <td>รหัสพนักงาน</td>
                        <td>ชื่อ</td>
                        <td>นามสกุล</td>
                        <td>เบอร์โทรศัพท์</td>
                        <td>อีเมล</td>
                        <td>การดำเนินงาน</td>
                    </tr>
                    <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($st->Staff_No); ?></td>
                        <td><?php echo e($st->Staff_Name); ?></td>
                        <td><?php echo e($st->Staff_Surname); ?></td>
                        <td><?php echo e($st->Staff_Phone); ?></td>
                        <td><?php echo e($st->Staff_Email); ?></td>
                        <td>
                        <form action="<?php echo e(route('staffs.destroy',$st->Staff_No)); ?>" method="POST">
                            <a class="btn btn-primary" href="<?php echo e(route('staffs.viewcus',$st->Staff_No)); ?>"><i class='fas fa-address-book' style='font-size:18px'></i> การดูแลลูกค้า</a>
                            <a class="btn btn-warning" href="<?php echo e(route('staffs.edit',$st->Staff_No)); ?>">แก้ไขข้อมูล</a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <button type="submit" class="btn btn-danger"><i class='fas fa-trash' style='font-size:18px'></i></button>
                        </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
            </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/staffs/index.blade.php ENDPATH**/ ?>