<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <center><h2>เพิ่มลูกค้าใหม่
                    <br>
                </div>
                <form action="<?php echo e(route('customer.store')); ?>" method="POST">
                <?php echo csrf_field(); ?> 
                <?php echo method_field("POST"); ?>   
                <table class="table table-striped" border='2'>
                       <tr>
                            <td>ชื่อลูกค้า:</td>
                            <td><input type=text name=Name></td>
                       </tr>
                       <tr>
                            <td>นามสกุล:</td>
                            <td><input type=text name=Surname></td>
                       </tr>
                       <tr>
                            <td>เบอร์โทรศัพท์:</td>
                            <td><input type=text name=Phone></td>
                       </tr>
                       <tr>
                            <td>อีเมล:</td>
                            <td><input type=text name=Email></td>
                       </tr>
                       
                       <tr>
                            <td>รหัสสถานะ:</td>
                            <td>
                                <select name="Status_No">
                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sta->Status_No); ?>"><?php echo e($sta->Status_No); ?> : <?php echo e($sta->Status_Name); ?> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                       </tr>
                       <tr>
                        <td></td>
                        <td conspan=2>
                        <button type="reset"  class="btn btn-danger">ยกเลิก</button>
                        <button type="submit"  class="btn btn-primary">บันทึกข้อมูล</button>
                        </td>
                        </tr>


                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/customer/create.blade.php ENDPATH**/ ?>