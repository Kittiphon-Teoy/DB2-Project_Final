<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <table border=1>
                    <tr>
                        <td>id<td>
                        <td>name <td>
                        <td>email<td>
                        <td>email_verified_at<td>
                        <td>password<td>
                        <td>remember_token<td>
                        <td>created_at<td>
                        <td>updated_at<td>
                      
                        
                    </tr>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($us->id); ?><td>
                        <td><?php echo e($us->name); ?><td>
                        <td><?php echo e($us->email); ?><td>
                        <td><?php echo e($us->email_verified_at); ?><td>
                        <td><?php echo e($us->password); ?><td>
                        <td><?php echo e($us->remember_token); ?><td>
                        <td><?php echo e($us->created_at); ?><td>
                        <td><?php echo e($us->updated_at); ?><td>
                       
                      
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/users/index.blade.php ENDPATH**/ ?>