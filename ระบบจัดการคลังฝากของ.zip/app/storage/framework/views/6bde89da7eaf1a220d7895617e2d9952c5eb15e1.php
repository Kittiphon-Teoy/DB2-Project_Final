<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <table border=1>
                    <tr>
                        <td>เลข<td>
                        <td>ชื่อ<td>
                        <td>วันที่เริ่ม<td>
                        <td>วันที่สิ้นสุด<td>
                        <td>เรท<td>
                    </tr>
                    <?php $__currentLoopData = $acctype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($act->Type_No); ?><td>
                        <td><?php echo e($act->Type_Name); ?><td>
                        <td><?php echo e($act->DateBegin); ?><td>
                        <td><?php echo e($act->DateEnd); ?><td>
                        <td><?php echo e($act->Rate); ?><td>
                      
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ACCType.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/ACCType/index.blade.php ENDPATH**/ ?>