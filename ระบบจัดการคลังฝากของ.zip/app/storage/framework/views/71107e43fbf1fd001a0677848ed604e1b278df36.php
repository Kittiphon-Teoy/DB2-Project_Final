<!DOCTYPE html>
<html>
<head>
    <title>Laravel 6 CRUD Application</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>
<div>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
   
</body>
</html>
<?php /**PATH /app/resources/views/Withdraw/layout.blade.php ENDPATH**/ ?>