<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
            <div class="panel panel-default">
                <div class="panel-heading">
                <div>
                <a class="btn btn-primary" href="">เพิ่มการบ้าน</a>
                    
                <br>
                <br>
                </div>
                    <table border=1>
                    <tr>
                        <td>Homework_ID<td>
                        <td>Homework_Name<td>
                        <td>Homework_Status<td>
                        <td>Homework_IDdetail<td>
                        <td>HomeworkStatistics_ID<td>
                        <td>User_ID<td>
                        <td colspan=2>การดำเนินงาน</td>
                    </tr>
                    
                    <?php $__currentLoopData = $homework; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($hw->Homework_ID); ?><td>
                        <td><?php echo e($hw->Homework_Name); ?><td>
                        <td><?php echo e($hw->Homework_Status); ?><td>
                        <td><?php echo e($hw->Homework_IDdetail); ?><td>
                        <td><?php echo e($hw->HomeworkStatistics_ID); ?><td>
                        <td><?php echo e($hw->User_ID); ?><td>
                        
                        <td>
                        <form action="" method="POST">
                            <a class="btn btn-primary" href="">แก้ไข</a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <button type="submit" class="btn btn-danger">ลบ</button>
                        </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/homework/index.blade.php ENDPATH**/ ?>