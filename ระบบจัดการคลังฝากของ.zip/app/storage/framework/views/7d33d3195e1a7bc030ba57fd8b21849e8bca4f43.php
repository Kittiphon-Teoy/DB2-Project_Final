<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <table border=1>
                    <tr>
                        <td>id<td>
                        <td>connection <td>
                        <td>queue<td>
                        <td>payload<td>
                        <td>exception<td>
                        <td>failed_at<td>
                    </tr>
                    <?php $__currentLoopData = $failed_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($tr->id); ?><td>
                        <td><?php echo e($tr->connection); ?><td>
                        <td><?php echo e($tr->queue); ?><td>
                        <td><?php echo e($tr->payload); ?><td>
                        <td><?php echo e($tr->exception); ?><td>
                        <td><?php echo e($tr->failed_at); ?><td>
                      
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('failed_jobs.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/failed_jobs/index.blade.php ENDPATH**/ ?>