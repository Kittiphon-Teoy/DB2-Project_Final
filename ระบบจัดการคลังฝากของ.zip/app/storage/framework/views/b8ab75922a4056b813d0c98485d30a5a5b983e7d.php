<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <center><h2>แก้ไขข้อมูลลูกค้า</h2></center>
                <br>
                </div>
                <form action="<?php echo e(route('customer.update',$cus->Customer_ID)); ?>" method="POST">
                <?php echo csrf_field(); ?> 
                <?php echo method_field("PUT"); ?>   
                <table class="table table-striped" border='2'>
                       <tr>
                            <td>ชื่อลูกค้า:</td>
                            <td><input type=text name=Name value="<?php echo e($cus->Name); ?>"></td>
                       </tr>
                       <tr>
                            <td>นามสกุล:</td>
                            <td><input type=text name=Surname value="<?php echo e($cus->Surname); ?>"></td>
                       </tr>
                       <tr>
                            <td>เบอร์โทรศัพท์:</td>
                            <td><input type=text name=Phone value="<?php echo e($cus->Phone); ?>"></td>
                       </tr>
                       <tr>
                            <td>อีเมล:</td>
                            <td><input type=text name=Email value="<?php echo e($cus->Email); ?>"></td>
                       </tr>
                       <tr>
                            <td>รหัสสถานะ:</td>
                            <td>
                                <select name="Status_No">
                                    <option value="<?php echo e($cus->Status_No); ?>"><?php echo e($cus->Status_No); ?></option>
                                    <option value="1">1:Normal</option>
                                    <option value="2">2:Bronze</option>
                                    <option value="3">3:Silver</option>
                                    <option value="4">4:Gold</option>
                                </select>
                            </td>
                       </tr>
                        
                       <tr>
                        <td></td>
                        <td conspan=2>
                        <button type="reset"  class="btn btn-danger">ยกเลิก</button>
                        <button type="submit"  class="btn btn-primary">แก้ไขข้อมูล</button>
                        </td>
                        </tr>


                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/customer/edit.blade.php ENDPATH**/ ?>