

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $acctype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                   แก้ไขชนิดบัญชี
                </div>
                <form action="<?php echo e(route('acctype.update',$act->Type_No)); ?>" method="POST">
                <?php echo csrf_field(); ?> 
                <?php echo method_field("PUT"); ?>   
                <table border=1>
                      
                       <tr>
                            <td>ชนิดบัญชี:<td>
                            <td><input type=text name=Type_No value="<?php echo e($act->Type_No); ?>"></td>
                       </tr>
                       <tr>
                            <td>ชื่อชนิด:<td>
                            <td><input type=text name=Type_Name value="<?php echo e($act->Type_Name); ?>"></td>
                       </tr>
                       <tr>
                            <td>วันที่เริ่ม:<td>
                            <td><input type=text name=DateBegin value="<?php echo e($act->DateBegin); ?>"></td>
                       </tr>
                       <tr>
                            <td>วันที่สิ้นสุด:<td>
                            <td><input type=text name=DateEnd value="<?php echo e($act->DateEnd); ?>"></td>
                       </tr>
                       <tr>
                            <td>เรท:<td>
                            <td><input type=text name=Rate value="<?php echo e($act->Rate); ?>"></td>
                       </tr>
                        
                       <tr>
                        <td conspan=2>
                        <button type="reset"  class="btn btn-primary">ยกเลิก</button>
                        <button type="submit"  class="btn btn-primary">แก้ไขข้อมูลข้อมูล</button>
                        </td>
                        </tr>


                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/acctype/edit.blade.php ENDPATH**/ ?>