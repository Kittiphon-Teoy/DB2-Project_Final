

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                   โอนเงิน
                </div>
                <form action="<?php echo e(route('account.inserttransfer')); ?>" method="POST">
                <?php echo csrf_field(); ?> 
                <?php echo method_field("POST"); ?>   
                <table border=1>
                        <tr>
                            <td>บัญชีต้นทาง:<td>
                            <td>
                                <select name="ACC_No_Source">
                                <?php $__currentLoopData = $account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($acc->ACC_No); ?>"><?php echo e($acc->ACC_No); ?> : <?php echo e($acc->ACC_Name); ?> &nbsp;&nbsp; <?php echo e($acc->ACC_Surname); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                       </tr>
                       <tr>
                            <td>บัญชีปลายทาง:<td>
                            <td>
                                <select name="ACC_No_Dest">
                                <?php $__currentLoopData = $account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($acc->ACC_No); ?>"><?php echo e($acc->ACC_No); ?> : <?php echo e($acc->ACC_Name); ?> &nbsp;&nbsp; <?php echo e($acc->ACC_Surname); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                       </tr>
                       <tr>
                            <td>จำนวนโอนเงิน:<td>
                            <td><input type=text name=Amount ></td>
                       </tr>
                       <tr>
                        <td conspan=2>
                        <button type="reset"  class="btn btn-primary">ยกเลิก</button>
                        <button type="submit"  class="btn btn-primary">โอนเงิน</button>
                        </td>
                        </tr>


                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/account/transfer.blade.php ENDPATH**/ ?>