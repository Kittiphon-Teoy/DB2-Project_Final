

<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <center><h2>เพิ่มของที่ฝาก</center>
                <br>
                </div>
                <form action="<?php echo e(route('customer.storeitem')); ?>" method="POST">
                <?php echo csrf_field(); ?> 
                <?php echo method_field("POST"); ?>   
                <table class="table table-striped" border='2'>
                       <tr>
                            <td>ชื่อของที่ฝาก:</td>
                            <td><input type=text name=Item_Name></td>
                       </tr>
                       <tr>
                            <td>จำนวนวันที่ฝาก:</td>
                            <td>
                                <select name="Price">
                                    <option value="50">15 วัน : 50 บาท 
                                    <option value="75">30 วัน : 75 บาท  
                                    <option value="100">มากกว่า 30 วัน : 100 บาท 
                                </select>
                            </td>
                       </tr>
                       <tr>
                            <td>ชื่อผู้ฝาก:</td>
                            <td><input type=text name=Item_Recipients></td>
                       </tr>
                       <tr>
                            <td>รายละเอียด:</td>
                            <td><input type=text name=Detail></td>
                       </tr>
                       <input type=hidden name=Customer_ID value="<?php echo e($cus->Customer_ID); ?>">
                       <tr>
                        <td></td>
                        <td conspan=2>
                        <button type="reset"  class="btn btn-primary">ยกเลิก</button>
                        <button type="submit"  class="btn btn-success">บันทึกข้อมูล</button>
                        </td>
                        </tr>


                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/customer/createitem.blade.php ENDPATH**/ ?>