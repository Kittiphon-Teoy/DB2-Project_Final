<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customer = DB::table('Customer')->get();
        return view('customer.index',compact('customer'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $status = DB::table('Status_Cus')->get();
        return view('customer.create',compact('status'));
    }

    public function createitem($id)
    {
        $customer = DB::table('Customer')->where('Customer_ID','=',$id)->get();
        return view('customer.createitem',compact('customer'));
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            
            'Name'=>'required',
            'Surname'=>'required',
            'Phone'=>'required',
            'Email'=>'required',
            'Status_No'=>'required'
         ]);
        DB::table('Customer')->insert([
            
            'Name'=>$request->Name,
            'Surname'=>$request->Surname,
            'Phone'=>$request->Phone,
            'Email'=>$request->Email,
            'Status_No'=>$request->Status_No
        ]);
        return redirect('customer');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $status = DB::table('Status_Cus')->get();
        $customer = DB::table('Customer')->where('Customer_ID','=',$id)->get();
        return view('customer.edit',compact('customer','status'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            
            'Name'=>'required',
            'Surname'=>'required',
            'Phone'=>'required',
            'Email'=>'required',
            'Status_No'=>'required'
         ]);
        DB::table('Customer')->where('Customer_ID','=',$id)->update([
            
            'Name'=>$request->Name,
            'Surname'=>$request->Surname,
            'Phone'=>$request->Phone,
            'Email'=>$request->Email,
            'Status_No'=>$request->Status_No
        ]);
        return redirect('customer');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::table('Customer')->where('Customer_ID','=',$id)->delete();
        return redirect('customer');
    }

    public function showitem($id)
    {
        $cushasstaff = DB::table('Customer_has_Staff')->where('Customer_ID','=',$id)->get();
        $item = DB::table('Item')->where('Customer_ID','=',$id)->get();
        $customer = DB::table('Customer')->where('Customer_ID','=',$id)->get();
        
        return view('customer.showitem',compact('item','customer','cushasstaff'));
    }

    public function storeitem(Request $request)
    {
        // เพิ่มข้อมูลในตาราง item
            DB::table("Item")->insert(
            [
                'Item_Name' => $request->Item_Name,
                'Item_Recipients' => $request->Item_Recipients,
                'Detail' => $request->Detail,
                'Price' => $request->Price,
                'Deposit_Date' => now(),
                'Customer_ID' => $request->Customer_ID
            ]
            );

        return redirect('customer');
    }

    public function destroyitem($id)
    {
        DB::table('Item')->where('Item_ID','=',$id)->delete();
        return redirect('customer');
    }

    public function InsertStatus(Request $request)
    {
        DB::table("Status_Item")->insert(
            [
                'Pickup_Date' => now(),
                'Status_Item' => $request->Status_Item,
                'Item_ID' => $request->Item_ID
            ]
            );
            return redirect('customer');
    }

    public function Status($id)
    {
        $item = DB::table('Item')->where('Item_ID','=',$id)->get();
        return view('customer.status',compact('item'));
    }

    public function ViewStatus($id)
    {
        $item = DB::table('Item')->where('Item_ID','=',$id)->get();
        $Status_Item = DB::table('Status_Item')->where('Item_ID','=',$id)->get();
        return view('customer.viewstatus',compact('item','Status_Item'));
    }

    public function Pickstaff()
    {
        $staff = DB::table('Staff')->get();
        $customer = DB::table('Customer')->get();
        return view('customer.pickstaff',compact('staff','customer'));
    }

    public function Storepickstaff(Request $request)
    {
        DB::table('Customer_has_Staff')->insert([
            
            'Customer_ID'=>$request->Customer_ID,
            'Staff_No'=>$request->Staff_No
        ]);
        return redirect('customer');
    }

        public function Calmember($id)
        {
            try {
                DB::select('call CalmemberV2(?)',array($id));
            } catch(\Illuminate\Database\QueryException $ex){
                return redirect('customer');
            }
            
            
        }
    
}
