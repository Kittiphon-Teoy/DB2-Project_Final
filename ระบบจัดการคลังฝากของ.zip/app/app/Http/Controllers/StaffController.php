<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class StaffController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $staffs = DB::table('Staff')->get();
        return view('staffs.index',compact('staffs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('staffs.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            
            'Staff_Name'=>'required',
            'Staff_Surname'=>'required',
            'Staff_Phone'=>'required',
            'Staff_Email'=>'required'
         ]);
        DB::table('Staff')->insert([
            
            'Staff_Name'=>$request->Staff_Name,
            'Staff_Surname'=>$request->Staff_Surname,
            'Staff_Phone'=>$request->Staff_Phone,
            'Staff_Email'=>$request->Staff_Email
        ]);
        return redirect('staffs');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $staffs = DB::table('Staff')->where('Staff_No','=',$id)->get();
        return view('staffs.edit',compact('staffs'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            
            'Staff_Name'=>'required',
            'Staff_Surname'=>'required',
            'Staff_Phone'=>'required',
            'Staff_Email'=>'required'
         ]);
         DB::table('Staff')->where('Staff_No','=',$id)->update([
            
            'Staff_Name'=>$request->Staff_Name,
            'Staff_Surname'=>$request->Staff_Surname,
            'Staff_Phone'=>$request->Staff_Phone,
            'Staff_Email'=>$request->Staff_Email
        ]);
        return redirect('staffs');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::table('Staff')->where('Staff_No','=',$id)->delete();
        return redirect('staffs');
    }

    public function Viewcus($id)
    {
        $cushasstaff = DB::table('Customer_has_Staff')->where('Staff_No','=',$id)->get();
        return view('staffs.viewcus',compact('cushasstaff'));
    }
}
