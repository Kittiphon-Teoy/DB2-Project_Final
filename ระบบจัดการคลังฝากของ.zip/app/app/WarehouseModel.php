<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WarehouseModel extends Model
{
    protected $table="Item";
    protected $fillable=[
        'Item_ID','Item_Name','Item_Recipients','Detail','Deposit_Date','Customer_ID'
    ];
}
