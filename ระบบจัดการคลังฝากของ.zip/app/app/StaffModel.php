<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StaffModel extends Model
{
    protected $table="Staff";
    protected $fillable=[
        'Staff_No','Staff_Name','Staff_Surname','Staff_Phone','Staff_Email'
    ];
}
