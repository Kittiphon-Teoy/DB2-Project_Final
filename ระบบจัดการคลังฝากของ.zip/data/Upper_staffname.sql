DELIMITER $$
DROP TRIGGER IF EXISTS Upper_staffname $$

CREATE TRIGGER Upper_staffname 

    BEFORE INSERT ON Staff
    FOR EACH ROW

BEGIN
    IF (New.Staff_Name IS NOT NULL) THEN
        SET New.Staff_Name=UPPER(New.Staff_Name);
        SET New.Staff_Surname=UPPER(New.Staff_Surname);
    END IF;

END $$
DELIMITER ;