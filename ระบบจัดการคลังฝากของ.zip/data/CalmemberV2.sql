DELIMITER $$
DROP PROCEDURE IF EXISTS CalmemberV2 $$

CREATE PROCEDURE CalmemberV2(IN ID INT)

BEGIN

    DECLARE PriceI INT DEFAULT 0;
    DECLARE RateS FLOAT DEFAULT 0.0;
    DECLARE Cus FLOAT;
    DECLARE Sta FLOAT;


    SELECT Price,Customer_ID INTO PriceI , Cus
    FROM Item WHERE Item_ID=ID;

    SELECT Status_No INTO Sta
    FROM Customer WHERE Customer_ID=Cus;

    SELECT Ratesale INTO RateS
    FROM Status_Cus WHERE Status_No=Sta;

    IF PriceI>50 THEN
        UPDATE Item SET Price=PriceI-RateS
        WHERE Item_ID=ID;
    ELSEIF PriceI>100 THEN
        UPDATE Item SET Price=PriceI-RateS-10      
        WHERE Item_ID=ID;
    END IF;



END $$
DELIMITER ;