DELIMITER $$
DROP TRIGGER IF EXISTS Edit_Upper_staffname $$

CREATE TRIGGER Edit_Upper_staffname

    BEFORE UPDATE ON Staff
    FOR EACH ROW 

BEGIN
    IF (New.Staff_Name IS NOT NULL) THEN
        SET New.Staff_Name=UPPER(New.Staff_Name);
        SET New.Staff_Surname=UPPER(New.Staff_Surname);
    END IF;

END $$
DELIMITER ;