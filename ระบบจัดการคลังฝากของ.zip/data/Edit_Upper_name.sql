DELIMITER $$
DROP TRIGGER IF EXISTS Edit_Upper_name $$

CREATE TRIGGER Edit_Upper_name

    BEFORE UPDATE ON Customer
    FOR EACH ROW 

BEGIN
    IF (New.Name IS NOT NULL) THEN
        SET New.Name=UPPER(New.Name);
        SET New.Surname=UPPER(New.Surname);
    END IF;

END $$
DELIMITER ;