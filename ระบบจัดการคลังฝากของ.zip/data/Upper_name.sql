DELIMITER $$
DROP TRIGGER IF EXISTS Upper_name $$

CREATE TRIGGER Upper_name 

    BEFORE INSERT ON Customer
    FOR EACH ROW

BEGIN
    IF (New.Name IS NOT NULL) THEN
        SET New.Name=UPPER(New.Name);
        SET New.Surname=UPPER(New.Surname);
    END IF;

END $$
DELIMITER ;