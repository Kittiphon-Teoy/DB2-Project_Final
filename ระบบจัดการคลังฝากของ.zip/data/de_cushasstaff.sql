DELIMITER $$
DROP TRIGGER IF EXISTS de_cushasstaff $$

CREATE TRIGGER `de_cushasstaff` BEFORE DELETE ON `Customer`
 FOR EACH ROW 
 BEGIN
    DELETE FROM Customer_has_Staff
    WHERE Customer_ID = old.Customer_ID

END $$
DELIMITER ;


