DELIMITER $$
DROP TRIGGER IF EXISTS de_status_item $$

CREATE TRIGGER `de_status_item` BEFORE DELETE ON `Item`
 FOR EACH ROW 
 BEGIN
    DELETE FROM Status_Item
    WHERE Item_ID = old.Item_ID

END $$
DELIMITER ;