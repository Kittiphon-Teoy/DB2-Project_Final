DELIMITER $$
DROP TRIGGER IF EXISTS de_item $$

CREATE TRIGGER `de_item` BEFORE DELETE ON `Customer`
 FOR EACH ROW 
 BEGIN
    DELETE FROM Item
    WHERE Customer_ID = old.Customer_ID

END $$
DELIMITER ;